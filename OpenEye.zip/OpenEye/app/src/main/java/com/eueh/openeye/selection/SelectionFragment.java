package com.eueh.openeye.selection;

import android.view.View;

import com.eueh.openeye.R;
import com.eueh.openeye.base.BaseFragment;

/**
 * Created by dllo on 16/12/19.
 */

public class SelectionFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_selection;
    }

    @Override
    public void initView(View view) {

    }


    @Override
    public void initData() {

    }
}
